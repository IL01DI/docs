---
# Mandatory fields
id: "9a8aa994-48cf-4973-a551-3be88ee3213c"
# Optional fields
title: "what are backlinks"
tags: []
source: ""
source_title: ""
source_description: ""
source_image_url: ""
created_date: "2024-07-27"
modified_date: "2024-07-27"
---
backlinks are links to notes that reference the current note