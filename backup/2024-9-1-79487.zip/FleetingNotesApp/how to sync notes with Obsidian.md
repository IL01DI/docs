---
# Mandatory fields
id: "674a6508-2979-49ce-86c5-5befdc69c718"
# Optional fields
title: "how to sync notes with Obsidian"
tags: []
source: "https://fleetingnotes.app/posts/sync-fleeting-notes-with-obsidian/"
source_title: ""
source_description: ""
source_image_url: ""
created_date: "2024-07-27"
modified_date: "2024-07-27"
---
1. Go to the community plugins in Obsidian & download 'Fleeting Notes Sync' plugin
2. Configure the plugin settings (Add user, pass, specify folder, etc.)
3. Run the sync command!