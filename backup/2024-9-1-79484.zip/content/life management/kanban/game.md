---

kanban-plugin: board

---

## Wishlist

- [ ] Ender Lilies


## Queued

- [ ] Wuthering Waves
- [ ] Arknights Endfield
- [ ] Girl's Frontline
- [ ] Neural Cloud
- [ ] Girl's Frontline 2
- [ ] Abyss New Dawn
- [ ] Minecraft
- [ ] Super Mario Bros. Wonder


## Playing

- [ ] Genshin Impact
- [ ] Arknights
- [ ] Brown Dust 2
- [ ] Eversoul
- [ ] Punishing Grave Raven
- [ ] Snowbreak: Containment Zone
- [ ] Azur Lane
- [ ] Honkai: Star Rail
- [ ] Nikke
- [ ] Blue Archive
- [ ] Outerplane
- [ ] Epic Seven


## Abandoned

- [ ] AFK Journey
- [ ] Banana
- [ ] CS:GO
- [ ] Atelier Resleriana
- [ ] Neural Cloud
- [ ] Reverse: 1999
- [ ] Honkai Impact 3rd
- [ ] Pokémon Masters EX
- [ ] Pokémon Go
- [ ] Evertale
- [ ] Star Wars: Galaxy of Heroes
- [ ] Mario Kart Tour
- [ ] Grand Cross: Age of Titans
- [ ] Postknight 2
- [ ] Postknight
- [ ] 
- [ ] Transformers: Earth Wars
- [ ] Pokémon Café Remix
- [ ] Idle Miner Tycoon
- [ ] Clash of Clans
- [ ] Guardian Tales
- [ ] Bridge Race
- [ ] Higan: Eruthyll
- [ ] The Legend of Zelda: Breath of the Wild
- [ ] The Battle of Polytopia
- [ ] Aethe Gazer
- [ ] AFK Arena
- [ ] Alchemy Stars
- [ ] Among Us
- [ ] Animal Crossing: New Horizons
- [ ] Animal Crossing: Pocket Camp
- [ ] Bacon
- [ ] Bloons TD Battles 2
- [ ] Sword Master Story
- [ ] Tower of Fantasy
- [ ] World of Tanks
- [ ] World of Warships
- [ ] Super Smash Bros Ultimate
- [ ] Splatoon 2
- [ ] Grand Chase
- [ ] Clash Royale
- [ ] KonoSuba


## Completed

- [ ] Pokémon Sun
- [ ] Pokémon Red
- [ ] Pokémon Blue
- [ ] Pokémon White
- [ ] Pokémon Omega Ruby
- [ ] Pokémon FireRed
- [ ] Pokémon SoulSilver
- [ ] Pokémon Let's Go Pikachu
- [ ] Mario Kart 7
- [ ] Mario Kart 8 Deluxe
- [ ] Mario Kart Wii
- [ ] The Legend of Zelda: Link's Awakening
- [ ] Pokémon Sword
- [ ] Super Mario Galaxy
- [ ] Super Mario Odyssey


## EoS (NOT COMPLETED)

- [ ] Girl Cafe Gun
- [ ] Princess Connect: ReDive




%% kanban:settings
```
{"kanban-plugin":"board","list-collapse":[false,false,false,false,false,false]}
```
%%