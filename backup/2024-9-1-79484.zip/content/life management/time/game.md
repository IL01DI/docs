1. If Monday or Tuesday:
	1. If between 6:30 and 7:15: 
		1. MM
		2. Arknights+ Eversoul
		3. Epic 7
	2. (7:30 - 9:15)
		1. HSR Weekly
			1. Weekly Bosses
			2. Farm
			3. Endgame Content
		2. GI
			1. Weekly Bosses + Daily Primogems
			4. Teapot
	3. (9:45 - 14:30):
		1. SCZ
		4. BD2 + Nikke
			- Nikke
				1. Claim free 2 hour resources
				2. Claim resources (idle type)
				3. Claim free 10 gems on cash shop
				4. Buy shop items by credits.
				5. If event:
					1. Challenge Mode.
					2. Story Mode.
					3. Mini game.
		1. PGR
		2. BA
		3. Outerplane + AL
	5. (16:45 - 19:30):
		1. Events
3. Wednesday, Friday, Saturday & Sunday
	1. (6:30 - 7:15): 
		1. MM
		2. Arknights+ Eversoul
		3. Epic 7
	2. (7:30 - 9:15)
		1. HSR
		2. GI
		3. SCZ
		4. BD2 + Nikke
		5. PGR + Nikke
		6. Outerplane + Nikke
		7. AL + Nikke
	3. (11:45 - 14:30):
		1. BA
		2. AL
	4. (16:45 - 19:30):
		1. Events
4. Thursday
	1. (6:30 - 9:15): 
		1. MM + AL
		2. Arknights + HSR
		3. GI
		1. SCZ
		2. BD2 + Nikke
		3. PGR
		4. BA + Eversoul
		5. Outerplane + Epic 7