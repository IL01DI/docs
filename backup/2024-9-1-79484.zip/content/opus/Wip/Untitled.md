No hay nada que no sea nada.
Ni siquiera ella puede escapar del todo.
Incluso lo más insignificante que sea sigue siendo significante.
Ya que es lo que es, pero no puede no ser, y no es lo que no es, pero no puede ser.
Ser o no ser, esa es la cuestión.
Lo que es todo es uno, y lo que no es uno es otro.

Mientras la inteligencia me ilumina, la experiencia me oscurece.
En donde sea tanto sensible como inteligible, la razón da forma y la imaginación da materia.
En forma, es.
En materia, se piensa.
Entonces, pienso, luego soy.
Ya que pensar requiere ser.
Aunque también, en materia, se dice.
Entonces, pensar y decir son semejantes.
Ya que ambos refieren al logos.
Así que ser es idéntico a pensar y decir.

El sentido inspira a la imaginación, no a la cognición.
Lo que aparece no es, sino que parece.
Uno es, otro parece.

Lo uno llamo “cosmos”; lo otro, “caos”.
El uno nombro “verdad”; el otro, “realidad”.
Ni el uno ni el otro dependen entre ellos.



No hay que confundir entre dicho y hecho.

El hombre es la medida de todas las cosas, en tanto que es y en cuanto que es.



Solo sé que no sé nada.

Pienso, luego soy.

Verdad: 