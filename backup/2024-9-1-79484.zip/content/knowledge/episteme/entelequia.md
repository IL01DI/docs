
> [!quote] _Física_, III, A, 201a (Gredos, Madrid 1995, p. 178)
>> El movimiento la entelequia de lo potencial en cuanto tal [en cuanto está en potencia].
>
> \- Aristóteles