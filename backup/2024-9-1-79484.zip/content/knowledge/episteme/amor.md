---
tags:
- ca
- philologia
- philosophia
---

> [!quote] _Les passions de l´âme_, a.79 (_Oeuvres philosophiques_, 3 vols.; Garnier, París 1973, vol. 3, p. 1012-1013).
>> L'amor és una emoció de l'ànima causada pel moviment dels esperits, que la incita a unir-se voluntàriament als objectes que li semblen convenients.
>
> \- René Descartes


