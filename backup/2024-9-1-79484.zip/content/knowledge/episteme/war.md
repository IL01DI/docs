
> [!quote]
>> War is the father of all things.
>
> \- Heraclitus of Ephesus