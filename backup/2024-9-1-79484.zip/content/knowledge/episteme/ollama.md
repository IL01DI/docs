Before installing:

> [!info] Note
> You should have at least 8GB of RAM available to run the 7B models, 16 GB to run the 13 B models, and 32 GB to run the 33 B models. ([Source](https://github.com/ollama/ollama/blob/main/README.md#model-library), 07/2024)

Not an option for me to have local AI as for now.