
> [!quote] [1013b, Capítol segon, Cinquè llibre, _Metafísica_ (Gredos, Madrid 1994, p.205-208)](https://www.wikisofia.cat/wiki/Recurs:Arist%C3%B2til:_els_primers_principis_i_les_causes)
>> Es diu «causa» (I) en un sentit, allò de què es fa quelcom, que és l'immanent (en això) [...]; (2) en un altre sentit, la forma i el model, és a dir, la definició de l'essència i els gèneres d'aquesta [...], així com les parts de la definició; (3) a més, allò d'on prové l'inici primer del canvi i del repòs [...]; (4) a més (està la causa entesa) com a fi, i aquest és allò per-el-com [...]. I també totes aquelles coses que, sent un altre el que inicia el moviment, s'interposen abans del fi [...]; i és que totes aquestes coses són per a la fi, si bé difereixen entre si en què les unes són accions i les altres, instruments.
>
> \- Aristòtil

