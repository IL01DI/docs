
> [!quote] [_Metafísica_, VII, 1032b (Gredos, Madrid 1994, p. 300)](https://www.wikisofia.cat/wiki/Recurs:Cita_Arist%C3%B2til_8)
>> I anomeno forma a l'essència de cada cosa, és a dir, a la seva entitat (substància) primera.
>
> \- Aristóteles

