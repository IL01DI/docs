> [!quote] [_Stromateis_ (DK, A 27)](https://www.wikisofia.cat/wiki/Recurs:Cites_d%27Anaximandre#)
>> El mar és un residu de la humitat primigènia. L'espai que envoltava la terra era humit i, després, el sol va evaporar part de la humitat... però la part que va quedar en les concavitats de la terra va formar el mar. A causa d'això el mar no deixa d'empetitir-se a mesura que el sol va assecant-lo i arribarà un moment en què s'assecarà.
>
> \- Anaximandre de Milet (i escrit per Alexandre d'Afrodisia)

