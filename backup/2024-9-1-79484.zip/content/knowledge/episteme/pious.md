---
aliases:
  - piadoso
---

> [!quote] _Euthyphro_
>> Is the pious loved by the gods because it is pious, or is it pious because it is loved by the gods?
>
> \- Socrates
>> [!note]-
>>  1. The pious is the same as what gods love.
>>  2. But not all gods agree with each other.
>>  3. If the gods love the pious because it is the pious, then it is not pious because it is loved by the gods, since the fact that the gods love something cannot be explained why the pious is the pious.
>> 1. But if it is not pious because it is loved by the gods, then what is pious?
>> 2. However, if both were right, then with the gods loving the pious because it is pious, and the pious being the pious because the gods love it, the pious is not the same as the god-beloved.
>> 	1. For what is the pious to be pious is not what the god-beloved is to be god-beloved.
>> 	2. For what is the god-beloved to be god-beloved is the fact that the gods love it.
>> 	3. Whereas what is the pious to be pious is something else.