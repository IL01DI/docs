---
tags:
  - en
  - philosophia
---
```
Definition:
```

