---
tags:
  - en
  - philosophia
---
```yml
Definition: Relation of one being oneself.
```

>[!quote]
>> Unit species of be
>
>\- Aristotle

If 2 things are the same, both have an equal identity.
