---
tags:
  - ca
  - philosophia
---
```yml
Definició: Procés mental del subjecte que abstreu el coneixement, parcial o total, d'un objecte.
```
