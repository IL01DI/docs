
> [!quote] https://www.wikisofia.cat/wiki/Recurs:Cites_Descartes_sobre_la_noci%C3%B3_idea
>> Anomeno idea a tot el que l'esperit concep d'una manera immediata.
>
>>D'entre els meus pensaments, uns són com a imatges de coses, i a aquests solos convé amb propietat el nom d'«idea».
>
>>D'aquestes idees, unes em semblen nascudes amb mi, altres estranyes i vingudes de fora, i altres fetes i inventades per mi mateix. Doncs tenir la facultat de concebre el que és en general una cosa, o una veritat, o un pensament, em sembla procedir únicament de la meva pròpia naturalesa; però si sento ara un soroll, si veig el sol, si sento calor, he jutjat fins al present que aquests sentiments procedien de certes coses existents fora de mi; i, finalment, em sembla que les sirenes, els hipogrifs i altres quimeres d'aquest gènere, són ficcions i invencions del meu esperit.

> [!quote] https://www.wikisofia.cat/wiki/Recurs:Hume:_idees_i_impressions
>> Totes les idees, especialment les abstractes, són naturalment febles i fosques.
>
> \- David Hume

> [!quote] https://www.wikisofia.cat/wiki/Recurs:Cita_Kant_11
>> Aquesta idea del _conjunt de tota possibilitat_,entès com a condició en la qual es basa la completa determinació de cada cosa, és, al seu torn, [...] _ideal_ de la raó pura.
>
> \- Immanuel Kant
