---
aliases:
  - incapacitat
  - impossible
---


> [!quote]
>> Impotencialitat és la privació de potencialitat –és a dir, del principi la naturalesa del qual hem explicat– que té lloc ja sigui d'una manera total, ja sigui en allò a què naturalment correspon posseir-la ja.
>
> \- Aristòtil