---
tags:
  - en
  - philosophia
---

>[!quote] _Theaetetus_
>>Wonder is the feeling of a philosopher, and philosophy begins in wonder.
>
>\-Socrates & Plato