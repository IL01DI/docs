
> [!quote]
>> L'odi és una emoció causada pels esperits, que incita a l'ànima a separar-se dels objectes que li semblen nocius.
>
> \- René Descartes