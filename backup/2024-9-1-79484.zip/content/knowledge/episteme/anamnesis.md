---
tags:
  - es
  - philosophia
aliases:
- recuerdo
---
> [!quote] _Menón_, _Fedón_, _Fedro_
>> Conocer es recordar.
>
>\- Plato
>1. El alma reside en el mundo inteligible.
>2. El conocimiento es eterno, absoluto e inmutable.
>3. Un alma, muchas vidas.
>	- El alma es inmortal, singular y eterno.
>	- La vida es mortal, plural y efímera.
>4. No hay memoria antes de nacer y después de morir.
>5. El alma puede acceder al conocimiento.

