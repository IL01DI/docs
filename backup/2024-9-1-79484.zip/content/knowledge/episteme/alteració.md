
> [!quote] [_Física_, III, 1, 200b 25-201a 16. (Gredos, Madrid 1995, p.177-178)](https://www.wikisofia.cat/wiki/Recurs:Arist%C3%B2til:_la_definici%C3%B3_del_moviment)
>> L'actualitat de l'alterable com a alterable és l'alteració.
>
> \- Aristotle