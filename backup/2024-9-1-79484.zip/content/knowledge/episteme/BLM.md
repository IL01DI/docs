---
tags:
  - en
  - philosophia
  - politica
  - ethica
aliases:
  - Black Lives Matter
---

The hatred towards humankind is unreasonable if one is also a human. As such, it is outrageous both the racism and the anti-racism. Not only is because of their motive to stop discrimination, but to also limit human's individual authority. Thus, the reason too.

I disagree with both sides, each of them balances the unjust justice of this cruel world. On the one hand, the racism doesn't take into account of the equality. On the other hand, the anti-racism doesn't accept their opinion. Just as Heraclitus said once, the perfect harmony is the war itself.

Moreover, why we, humans, call them black when they are also humans? But more importantly, why I have to say them when we should say we as ours? As if those people treated as humans, not as colours, which is why the cultural influence might have affected the racism's mind.