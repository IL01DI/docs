
> [!quote]
>>Todo lo que no es Dios es bueno, porque es deseado por Dios, y no al revés
>
> \- Juan Duns Scoto