---
aliases:
  - acte
  - acto
  - Acte
  - Acto
  - Actualitat
  - Actualidad
  - actualidad
---

> [!quote]
>> Actualitat és, doncs, que la cosa existeixi, però no com diem que existeix en potencialitat.
>
> \- Aristòtil

