
> [!quote] [_Ref._ I,6, 6 (A 11)](https://www.wikisofia.cat/wiki/Recurs:Cites_d%27Anaximandre#)
>> Els éssers vius van néixer de l'evaporació de l'element humit deguda al sol; i que l'home, originàriament, s'assemblava a un altre ésser, a saber, a un peix.
>
> \- Anaximandre de Milet (i escrit per Hipòlit)

> [!quote] [Obra desconeguda, V, 19, 4 (A 30)](https://www.wikisofia.cat/wiki/Recurs:Cites_d%27Anaximandre#)
>> Els primers éssers vius van néixer de la humitat i coberts de teguments espinosos, però que, tan aviat com van créixer, van emergir cap a la part més seca, van partir el tegument i van continuar vivint durant un petit espai de temps.
>
> \- Anaximandre de Milet (i escrit per Aeci)

> [!quote] [_Strom._ (A 10)](https://www.wikisofia.cat/wiki/Recurs:Cites_d%27Anaximandre#)
>> A més que l'home, originàriament, va néixer d'éssers d'una altra espècie, recolzant-se en el fet que mentre els altres éssers de seguida troben aliment per a la seva subsistència, l'home és l'únic que necessita un llarg període de criança; per això, si originàriament hagués estat el que és ara, no hauria pogut sobreviure mai.
>
> \- Anaximandre de Milet (i escrit per Plutarc)

> [!quote] [_Strom._ (A 10)](https://www.wikisofia.cat/wiki/Recurs:Cites_d%27Anaximandre#)
>> Van néixer de l'aigua i la terra quan estaven calentes uns peixos o éssers semblants a peixos. Els homes es van formar dins d'aquests éssers i els petits es van quedar entre ells fins al temps de la pubertat; després, per fi, els éssers es van obrir pas i van emergir homes i dones capaços ja de trobar el seu propi sosteniment.
>
> \- Anaximandre de Milet (i escrit per Censori)