
> [!quote] _Metafísica_, V, 12, 1019a-1020a (Gredos, Madrid 1994, p. 234-237)
>> Així doncs, la definició principal de la potencialitat, en el seu sentit primari, serà: principi productor de canvi en un altre, o (en això mateix, però) en tant que altre.
>
> \- Aristòtil
