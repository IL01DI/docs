
> [!quote] [_An Enquiry Concerning Human Understanding_, Section 5, part 1 (Alianza, Madrid 1994, 8ª ed., p. 70)](https://www.wikisofia.cat/wiki/Recurs:Hume:_el_costum,_fonament_dels_raonaments_causals)
>> Any belief in a real matter of fact or existence derives merely from an object present to the memory or to the senses, and from a habitual conjunction between this and an object.
>
> \- David Hume
>> [!note]-
>> -  Habit is the foundation of causal reasoning.

> [!quote] [_A Treatise of Human Nature_ (Revista Teorema, Valencia 1977, p. 16)](https://www.wikisofia.cat/wiki/Recurs:Hume:_el_costum,_guia_de_la_vida)
>> We are determined only by the habit of assuming that the future is conformable to the past.
>
> \- David Hume
>> [!note]-
>> - Habit is the guide of life.

