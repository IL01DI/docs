
> [!quote]
>>  L'ànima és, en definitiva, una entelèquia primera d'un cos natural que té la vida en potència, és a dir, d'un cos organitzat.
>
> \- Aristòtil

