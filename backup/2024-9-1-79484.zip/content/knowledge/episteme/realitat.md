---
tags:
- philosophia
---
```yml
definitio: conformitat les-g res-g cum lu conceptu que ellas-p-g forma-p le-p ment-p.
confusio: veritat
```