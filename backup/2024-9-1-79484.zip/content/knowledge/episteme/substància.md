
> [!quote] [_Categories_, 5, 3b (_Obras_, Aguilar, Madrid 1973, 2ª ed., p. 234)](https://www.wikisofia.cat/wiki/Recurs:Cita_d%27Arist%C3%B2til_2)
>> El sentit primari més veritable i estricte del terme substància és a dir que és allò que mai es predica d'una altra cosa ni pot trobar-se en un subjecte.
>
> \- Aristòtil
>> [!notes]- Nota
>> - El real ésser com a individu
>> - Subjecte, essència i forma
>> - Forma a l'essència de cada cosa, és a dir, a la seva substància primera
>> - Subjecte que no necessita una altra cosa per a ser
>> - Substrat dels canvis accidentals
>> - Essència d'una cosa
>> - Forma o actualitat que fa que una cosa sigui el que és

> [!quote] [_Els principis de la filosofia_, I, 51 (Reus, Madrid 1925, p., 48)](https://www.wikisofia.cat/wiki/Recurs:Cita_Descartes_12)
>> Per substància, no podem entendre una altra cosa que el que existeix de tal forma que no té necessitat sinó de si mateix per a existir
>
> \- René Descartes
>> [!notes]- Nota
>> - Subjecte que no necessita una altra cosa per a ser
>> - Substrat dels canvis accidentals

