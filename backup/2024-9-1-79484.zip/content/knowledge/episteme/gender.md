---
tags:
- en
- philosophia
- sociologia
- ethike
---

