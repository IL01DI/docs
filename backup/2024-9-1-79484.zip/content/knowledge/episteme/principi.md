
> [!quote] [1012b, Capítol primer, Cinquè llibre, _Metafísica_ (Gredos, Madrid 1994, p.205-208)](https://www.wikisofia.cat/wiki/Recurs:Arist%C3%B2til:_els_primers_principis_i_les_causes)
>> S'anomena «principi» (1) l'extrem d'una cosa a partir de la qual pot un començar a moure's [...]; (2) i allò a partir de què cada cosa pot realitzar-se millor [...]; (3) i la primera cosa a partir de la qual es fa quelcom, que és l'immanent (en això) [...]; (4) i la cosa primera de què quelcom és compost, que és l'immanent (en això) i no es pot descompondre, és a dir, d'on naturalment s'originen el moviment i el canvi [...]; (5) i allò per la voluntat del qual es mou el que és mogut i canvia el que és canviat [...]. (6) A més, es diu també que és principi (d'una cosa) el primer a partir del qual cosa la cosa resulta cognoscible [...].
>
> \- Aristòtil

> [!quote] [1012b, Capítol primer, Cinquè llibre, _Metafísica_ (Gredos, Madrid 1994, p.205-208)](https://www.wikisofia.cat/wiki/Recurs:Arist%C3%B2til:_els_primers_principis_i_les_causes)
>> En altres sentits es parla també de «causes», ja que totes les causes són principis. I certament el comú a tot tipus de principis és ser _el primer a partir del qual_ alguna cosa és, o es produeix, o es coneix. I d'ells, uns són immanents i uns altres són extrínsecs, i per aquest motiu principi siguin la naturalesa i l'element, el pensament i la voluntat, l'entitat i el _per a què. I_ és que el bé i la bellesa són principi, en molts casos, tant del coneixement com del moviment.
>
> \- Aristòtil
