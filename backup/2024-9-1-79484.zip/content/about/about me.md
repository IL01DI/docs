Q: Who are you?
A: Good question, stranger. Who am I? I'm a person, a human being, a mammal, an animal, a living being, a thing; just like you.

Q: What is your name?
A: My name? Huh, are you so interested about names? Don't you think I need some privacy from someone I do not know such as yourself? Never mind, my real name isn't important, nor you should care it, since it is a common-bored one. But… you can call me as "Al Vignh", this one is much better, original that no one has ever used it. A person must have a unique name to identify a specific individual.

Q: What is your MBTI (Myers-Briggs Type Indicator)?
A: I do not seek superficial personality type, since each one is as unique as impossible to define oneself. But… if you insist so, then my guess would seem to be INTP.

Q: What is your horoscope?
A: I do not seek astromancy, since the stars do not dictate who one is. But if you insist so, which horoscope sign? I'm sure you would say the western one, but I would prefer to say every horoscope that tries to define me. In addition, I will deny each one's designation to me. Hence, in the Western zodiac I'm considered as Sagittarius, equivalent to _dhanusa_ in Jyotisha zodiac; while the Chinese zodiac represents me as the Rooster.