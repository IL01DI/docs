
|                  | singular | dual | plural |
| ---------------- |:--------:|:----:|:------:|
| **with case**    |    -e    | -ez  |  -es   |
| **without case** |    -    |  -z  |   -s   |

