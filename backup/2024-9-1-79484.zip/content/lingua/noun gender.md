Last vocal of the nominative case determines the gender.

| feminine | masculine | ambiguous | indefinite | neuter |
|:--------:|:---------:|:---------:|:----------:|:------:|
|    -a    |    -o     |    -u     |     -i     |   -e   |
