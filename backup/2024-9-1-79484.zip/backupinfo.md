```
ShareMyPlugin.md:
  digest: ed0e555c7d3ab0fba27178b3c64dbae0229479e964a7943aecd145ed4a785da7
  filename: ShareMyPlugin.md
  mtime: 1725221070641
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-09-01T20:04:30.641Z
Untitled.md:
  digest: 59aa2888832d19ca184a21a8378edb994f4a1b6c33e2922aa3af347ca3920150
  filename: Untitled.md
  mtime: 1723992454000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-08-18T14:47:34.000Z
home.md:
  digest: 347b8c5b550219a37641e7c1898813e365cc8e581a39f2092acc40a9b90480bb
  filename: home.md
  mtime: 1723737762000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-08-15T16:02:42.000Z
docs/Waydroid/Usage/Troubleshooting.md:
  digest: e0e614a98b571187e0739033ca0475f80667683c67be1ed7c0a2deb295cf48a4
  filename: docs/Waydroid/Usage/Troubleshooting.md
  mtime: 1723115682000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-08-08T11:14:42.000Z
docs/Waydroid/Usage/Installation.md:
  digest: 60012b02e2b0370799530aa96be7df6738ce225abbf524295bb163dbb1b032c6
  filename: docs/Waydroid/Usage/Installation.md
  mtime: 1723115763000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-08-08T11:16:03.000Z
docs/Python/0. Introduction to Python.md:
  digest: a1a0fb019933a2a90db1ba2ebb79d871bcaf4ba8e5879edcf05219df8106c9f4
  filename: docs/Python/0. Introduction to Python.md
  mtime: 1722270255000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-07-29T16:24:15.000Z
docs/Python/3.2. Python Variables - Assign Multiple Values.md:
  digest: c87a237e9783997b0ba7035be8b34249224bca6a07fde81f1a31cc18ac075680
  filename: docs/Python/3.2. Python Variables - Assign Multiple Values.md
  mtime: 1722270255000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-07-29T16:24:15.000Z
docs/Python/3. Python Variables .md:
  digest: a4a73cc24cfecd44d53f54ce409f6e8467a67c73670f29efedcf02b02c4a4363
  filename: docs/Python/3. Python Variables .md
  mtime: 1722270255000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-07-29T16:24:15.000Z
docs/Python/2. Python Comments.md:
  digest: 77062dbed1ff0c7eb095d3886647a58eded732f56a6268f51867a3c3b7ea5351
  filename: docs/Python/2. Python Comments.md
  mtime: 1722270255000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-07-29T16:24:15.000Z
docs/Python/3.1. Python Variable Names.md:
  digest: 3d89a65a61cc96e013affe7b1283e5396f797adaf049863376e93934911ca6f1
  filename: docs/Python/3.1. Python Variable Names.md
  mtime: 1722270255000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-07-29T16:24:15.000Z
docs/Obsidian.md/Obsidian Sync.md:
  digest: 3b2b11baab566a55d81e8ab513db4a17cb5a8392fe5b98c822d1a364cb5f5fb3
  filename: docs/Obsidian.md/Obsidian Sync.md
  mtime: 1723205538000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-08-09T12:12:18.000Z
docs/Obsidian.md/Obsidian Publish.md:
  digest: a8fe0ef44cb1dcd705bef4270d9ca21cc16fbabbac7b3dac2b03b4197ce11fef
  filename: docs/Obsidian.md/Obsidian Publish.md
  mtime: 1722332150000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-07-30T09:35:50.000Z
docs/Documentation for Latina/1. Parts of Speech.md:
  digest: 6c48cf4e77490e9196e6744e51362788a131f7f2bda50849b85293280b3809d2
  filename: docs/Documentation for Latina/1. Parts of Speech.md
  mtime: 1725209996000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-09-01T16:59:56.000Z
docs/Documentation for Latina/2. Word Order.md:
  digest: 2665e0ee6658d3c15b313c7c8f635c9d240932c01c01987979205791e718a5f1
  filename: docs/Documentation for Latina/2. Word Order.md
  mtime: 1723917139000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-08-17T17:52:19.000Z
docs/index.md:
  digest: 9aa07f5c682b6b8a5024c8adc0bf7e0520a8ad0afc6c37e2e3ca2e152e36ef03
  filename: docs/index.md
  mtime: 1723116500000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-08-08T11:28:20.000Z
docs/HOW TOs/how to be digitally minimal.md:
  digest: 1db0005a13d575f3bd5cdbf6617cc3fc65e8a612a03d62cf0551c9ad52a95a75
  filename: docs/HOW TOs/how to be digitally minimal.md
  mtime: 1722517389000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-08-01T13:03:09.000Z
docs/HOW TOs/how to create a language.md:
  digest: 97f96b86ddbaaf3baeda6c62847408f8b3463671379d09a0c8cdf0ef3dc92aa9
  filename: docs/HOW TOs/how to create a language.md
  mtime: 1722347711000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-07-30T13:55:11.000Z
docs/Documentation for English/6. Semantic.md:
  digest: 02ead0360dc4e50677ad1a65a34ed3d4c5b5a57b9f63cfde1c806eba4d25d95a
  filename: docs/Documentation for English/6. Semantic.md
  mtime: 1722416841000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-07-31T09:07:21.000Z
docs/Documentation for English/1. Phonology.md:
  digest: 015ab73a0f34dbcb68aa4da412adb47e65a93bb0f5f190679b9aea344228c9be
  filename: docs/Documentation for English/1. Phonology.md
  mtime: 1723450296000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-08-12T08:11:36.000Z
docs/Documentation for English/5. Pragmatic.md:
  digest: 1107a0ad3208b60fb44a2db0935159bcff90ebb45747ee43349e95e8e6701436
  filename: docs/Documentation for English/5. Pragmatic.md
  mtime: 1722416865000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-07-31T09:07:45.000Z
docs/Documentation for English/2. Morphology.md:
  digest: 7566e5c2c70a0bc28f80e183c6550e30a136d14119b5ae9b5a07cd1548302b58
  filename: docs/Documentation for English/2. Morphology.md
  mtime: 1722417884000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-07-31T09:24:44.000Z
docs/Documentation for English/3. Syntax.md:
  digest: 8bc0ca6f6bbc5081839697ed7ab180894500b06c14470fb6296423ec3ee4ae23
  filename: docs/Documentation for English/3. Syntax.md
  mtime: 1723450410000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-08-12T08:13:30.000Z
docs/Documentation for English/4. Morphosyntax.md:
  digest: ce40a36dd0f6d9efa74fabbc8871ec9c11f21fa190fd9423fe4ccbc056de9626
  filename: docs/Documentation for English/4. Morphosyntax.md
  mtime: 1723395350000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-08-11T16:55:50.000Z
content/assets/5CAROmZpll-700.webp:
  digest: a46afd290d3bdbebeb1ed8fb672f8d40d54da7caa0b24483725bb579e638b5f2
  filename: content/assets/5CAROmZpll-700.webp
  mtime: 1722273372000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-07-29T17:16:12.000Z
content/assets/BfxGAQpDcz-700.webp:
  digest: da8ba871a638cf2f376ab567833bf31ae00b6428915b96a9f77954a21aa189e1
  filename: content/assets/BfxGAQpDcz-700.webp
  mtime: 1722272584000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-07-29T17:03:04.000Z
content/assets/Pasted image 20240730103144.png:
  digest: 5217cf3ef207e4a6d12893513801b28abd505955c51ffdea3a41fb921daa6f6d
  filename: content/assets/Pasted image 20240730103144.png
  mtime: 1722328304000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-07-30T08:31:44.000Z
content/assets/Pasted image 20240730100738.png:
  digest: aa60f562a06643aa27676a468eba764878adba188f40f79c29839eb2fdd800e3
  filename: content/assets/Pasted image 20240730100738.png
  mtime: 1722326858000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-07-30T08:07:38.000Z
content/assets/Pasted image 20240730100705.png:
  digest: bc1cf5364f8eaeee7a9f7bedee4585b055d39621fdd4b5b4264fa0cc2776e636
  filename: content/assets/Pasted image 20240730100705.png
  mtime: 1722326825000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-07-30T08:07:05.000Z
content/knowledge/mathema/Calculus.md:
  digest: 3cc9c3f03ca67ff0f1bd029f4c44dedccd8ae019b6950a06a026ee8175823748
  filename: content/knowledge/mathema/Calculus.md
  mtime: 1722250900000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-07-29T11:01:40.000Z
content/knowledge/episteme/mar.md:
  digest: 7d869e19849b943df8691da6154b55513eba80cb789587dd1443d8b004158d2a
  filename: content/knowledge/episteme/mar.md
  mtime: 1723149372000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-08-08T20:36:12.000Z
content/knowledge/episteme/impotencialitat.md:
  digest: 041d1ec160ebf345284b3bd25c15596eddedcd7e9a77e94dc275f8175fa4a10a
  filename: content/knowledge/episteme/impotencialitat.md
  mtime: 1723138484000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-08-08T17:34:44.000Z
content/knowledge/episteme/odi.md:
  digest: 157dc9d1eb3207648885fe537d47f2f6a624db0359d52fc9a9ef4386c5ded4aa
  filename: content/knowledge/episteme/odi.md
  mtime: 1723135020000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-08-08T16:37:00.000Z
content/knowledge/episteme/Second Brain.md:
  digest: f90bf5571dd6ba17c86840851543aa1b574c4e349752cd6a64e55605c18eb545
  filename: content/knowledge/episteme/Second Brain.md
  mtime: 1723127010000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-08-08T14:23:30.000Z
content/knowledge/episteme/actualitat.md:
  digest: 730157a69a6cf397863de8cbf522e41b58a36cbedefbb1b3aa15e8d086088449
  filename: content/knowledge/episteme/actualitat.md
  mtime: 1723138141000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-08-08T17:29:01.000Z
content/knowledge/episteme/causa.md:
  digest: f402a35b0bf3634f8a1db288fa227dfd9926248aff2cc1509ad828285b58ce10
  filename: content/knowledge/episteme/causa.md
  mtime: 1723143965000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-08-08T19:06:05.000Z
content/knowledge/episteme/essència.md:
  digest: 1ec3a316c87786a8ac0a6cd19ad4b568ad40206f432ab3f2aef9ecad8647f409
  filename: content/knowledge/episteme/essència.md
  mtime: 1723139854000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-08-08T17:57:34.000Z
content/knowledge/episteme/ànima.md:
  digest: 71b2ab1db9a912e1c633b612291cedde6c5ebd0bd6d000b5241157e825c948ef
  filename: content/knowledge/episteme/ànima.md
  mtime: 1723137077000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-08-08T17:11:17.000Z
content/knowledge/episteme/ser.md:
  digest: d96ddeb29a36dc2f56232b62ecd77aba5fbef4e3f5717d70639693e46b159b99
  filename: content/knowledge/episteme/ser.md
  mtime: 1723151650000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-08-08T21:14:10.000Z
content/knowledge/episteme/OpenAI.md:
  digest: afdd91b6dba57d17046208e564fba97643e6e99ae3cbb8b742e706ffa4df93fb
  filename: content/knowledge/episteme/OpenAI.md
  mtime: 1722250900000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-07-29T11:01:40.000Z
content/knowledge/episteme/amor.md:
  digest: 4c1a0e2fbd535e1d976e4f1a16a1b6bd4da595caaa793bd4baa332a1458c2f8f
  filename: content/knowledge/episteme/amor.md
  mtime: 1723134394000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-08-08T16:26:34.000Z
content/knowledge/episteme/BLM.md:
  digest: 8c0207934383003fff0e5d5844ea76d6912f99af39361104d79caaa038c5ef95
  filename: content/knowledge/episteme/BLM.md
  mtime: 1723134766000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-08-08T16:32:46.000Z
content/knowledge/episteme/History of the life.md:
  digest: cbf7f359a86e43d8f1526679f192ee49df577cf90a6080fe65770bb808ded038
  filename: content/knowledge/episteme/History of the life.md
  mtime: 1723114982000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-08-08T11:03:02.000Z
content/knowledge/episteme/habit.md:
  digest: 78106bc376d6037d89a2541d836d2d050b47151f46df4788d93bc609786ecbbd
  filename: content/knowledge/episteme/habit.md
  mtime: 1723141629000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-08-08T18:27:09.000Z
content/knowledge/episteme/gender.md:
  digest: 5831d9eef61087fb21b3563e54dbe831490b34ecf235a5e5ddf606b73ab3a4ca
  filename: content/knowledge/episteme/gender.md
  mtime: 1722412265000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-07-31T07:51:05.000Z
content/knowledge/episteme/entelequia.md:
  digest: 66b3bc90b90bfa2b43e70216d293de60cff0624fbb1f283e2a57d7d26cb15ef6
  filename: content/knowledge/episteme/entelequia.md
  mtime: 1723136793000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-08-08T17:06:33.000Z
content/knowledge/episteme/History of the atomic model.md:
  digest: 52486210b93d4fcddbac6f066e3aa72a894a73eea08a86d737800c5a8d021f7c
  filename: content/knowledge/episteme/History of the atomic model.md
  mtime: 1722270222000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-07-29T16:23:42.000Z
content/knowledge/episteme/déu.md:
  digest: e0d8af6152c7eab51fbbce9dda2534cf2784b3d102fc76eb1f28cbc642a9c543
  filename: content/knowledge/episteme/déu.md
  mtime: 1723298568000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-08-10T14:02:48.000Z
content/knowledge/episteme/abstracció.md:
  digest: bbd6d0ca709cc561d81c1f60c817da7cd4b27b4c6a30ca103eda13fb9af6b602
  filename: content/knowledge/episteme/abstracció.md
  mtime: 1723134761000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-08-08T16:32:41.000Z
content/knowledge/episteme/idea.md:
  digest: e2e92ef14e008528876bebfeff595b73e64fba8b0a80a577651abd06ddbc3f02
  filename: content/knowledge/episteme/idea.md
  mtime: 1723142319000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-08-08T18:38:39.000Z
content/knowledge/episteme/vida.md:
  digest: dffaf99b5a1302d256e6023929ce23b5336c0817feb074d4164c4babea35bd20
  filename: content/knowledge/episteme/vida.md
  mtime: 1723149829000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-08-08T20:43:49.000Z
content/knowledge/episteme/nothing.md:
  digest: c5e6678790ddf77610248d04a5728875724e67a8ac39e23365af53c6369b044f
  filename: content/knowledge/episteme/nothing.md
  mtime: 1723152537000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-08-08T21:28:57.000Z
content/knowledge/episteme/realitat.md:
  digest: 13a07ba1c35301366ef44a075485cd3514422ee830716ed54e03fc783480710c
  filename: content/knowledge/episteme/realitat.md
  mtime: 1723118900000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-08-08T12:08:20.000Z
content/knowledge/episteme/veritat.md:
  digest: cd63f5620de72fd1b9a2748d70a4f6cee2bb930302e0210453e0416d1fffc68b
  filename: content/knowledge/episteme/veritat.md
  mtime: 1723369656000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-08-11T09:47:36.000Z
content/knowledge/episteme/pious.md:
  digest: 3cae8b248d814594ccc879ba0c5f8819755a97b307a999bc1d5fa587a02bc62b
  filename: content/knowledge/episteme/pious.md
  mtime: 1723125713000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-08-08T14:01:53.000Z
content/knowledge/episteme/alteració.md:
  digest: 6eb2ff5330710d9f94006c06fccc23f41a77b16f0d149fa6025c1556f1502554
  filename: content/knowledge/episteme/alteració.md
  mtime: 1723133273000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-08-08T16:07:53.000Z
content/knowledge/episteme/PARA Method.md:
  digest: f7b970bf1875cec2b5f7b0114528c045afe5b06a5236080ea8f6f85cfa8b6ce7
  filename: content/knowledge/episteme/PARA Method.md
  mtime: 1722250900000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-07-29T11:01:40.000Z
content/knowledge/episteme/pecat.md:
  digest: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
  filename: content/knowledge/episteme/pecat.md
  mtime: 1723126918000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-08-08T14:21:58.000Z
content/knowledge/episteme/Verbal Tense.md:
  digest: 445c34dde6767e7de8d223b43112b006886ae6c6434917f40184bb249b75d748
  filename: content/knowledge/episteme/Verbal Tense.md
  mtime: 1722250900000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-07-29T11:01:40.000Z
content/knowledge/episteme/CODE Model.md:
  digest: 0049b87ab0c4f1185d5097025f6256becbcf96a708dc2c7e437b67ce48fc1a98
  filename: content/knowledge/episteme/CODE Model.md
  mtime: 1722270222000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-07-29T16:23:42.000Z
content/knowledge/episteme/identity.md:
  digest: afb47b2df0964ff7068588832b9c4c2f239e0c1f31da62dddbc1ec8084e0096f
  filename: content/knowledge/episteme/identity.md
  mtime: 1723119522000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-08-08T12:18:42.000Z
content/knowledge/episteme/knowledge.md:
  digest: 010525f2b9c200ec956a648af4e28ceca489ff652916e11dbed40ac78b858624
  filename: content/knowledge/episteme/knowledge.md
  mtime: 1723119522000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-08-08T12:18:42.000Z
content/knowledge/episteme/aoristos.md:
  digest: 574566ed82fa8b896325e98854bd0c41983a0b3136da961c7c11680887880d45
  filename: content/knowledge/episteme/aoristos.md
  mtime: 1723820136000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-08-16T14:55:36.000Z
content/knowledge/episteme/ollama.md:
  digest: 2b9503d4cb8bb90f573060300ad90ed3f65f892791d203e6f58fe7c3b56143dd
  filename: content/knowledge/episteme/ollama.md
  mtime: 1722250900000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-07-29T11:01:40.000Z
content/knowledge/episteme/motion.md:
  digest: 2c93fc76949c30d4fdee6a68960bb2e0ff1d23a367b444c4e872812728df3515
  filename: content/knowledge/episteme/motion.md
  mtime: 1723225850000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-08-09T17:50:50.000Z
content/knowledge/episteme/potencialitat.md:
  digest: 625f896f5ddd989bc4457d522dc41b26dee844ba7e57bf62e29b1381aa6be149
  filename: content/knowledge/episteme/potencialitat.md
  mtime: 1723137919000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-08-08T17:25:19.000Z
content/knowledge/episteme/Aristoteles.md:
  digest: 9f38ace858f278d0968a4bbcf110457b3583ce47f30d7a691660afcd92852044
  filename: content/knowledge/episteme/Aristoteles.md
  mtime: 1725220974000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-09-01T20:02:54.000Z
content/knowledge/episteme/principi.md:
  digest: 7643ebc24e5cbe2bfafbd930d9d50b8c47e97cbcfc15d8911d6979d91752648e
  filename: content/knowledge/episteme/principi.md
  mtime: 1723143946000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-08-08T19:05:46.000Z
content/knowledge/episteme/wonder.md:
  digest: 8e117df97d709b3469beef2287bd06354c4fb5b82750f11f3ec736ef3f81868d
  filename: content/knowledge/episteme/wonder.md
  mtime: 1722250900000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-07-29T11:01:40.000Z
content/knowledge/episteme/anamnesis.md:
  digest: e66d01a80dbe4e8b1dcbc371a731ebc479c88352ff93f1f2eea1858f03e2821b
  filename: content/knowledge/episteme/anamnesis.md
  mtime: 1723134764000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-08-08T16:32:44.000Z
content/knowledge/episteme/war.md:
  digest: bfc3ac8b84d7a32ef04898631e57273d8373f58e676049773f58ce87ab3ab297
  filename: content/knowledge/episteme/war.md
  mtime: 1723134933000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-08-08T16:35:33.000Z
content/knowledge/episteme/libertad.md:
  digest: 3e44a1ef0126c78c52628d6b327fc85c921cfc500adea2ae466f13918e142902
  filename: content/knowledge/episteme/libertad.md
  mtime: 1723128204000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-08-08T14:43:24.000Z
content/knowledge/episteme/substància.md:
  digest: ea0a0b49e5a3bc3ea64acbdb0806e9274e229cf9f226611e60758efcc9b903c5
  filename: content/knowledge/episteme/substància.md
  mtime: 1723140910000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-08-08T18:15:10.000Z
content/knowledge/episteme/saber.md:
  digest: 0d39d6117f7d40981c7b7933842581ca206ff187a092d473967fc5883e430d20
  filename: content/knowledge/episteme/saber.md
  mtime: 1723118912000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-08-08T12:08:32.000Z
content/knowledge/episteme/infinit.md:
  digest: 8c68c1713ad05e1281e1ec832a9a058d6f0139cb3d0ca96bb97e275b2331285b
  filename: content/knowledge/episteme/infinit.md
  mtime: 1723150542000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-08-08T20:55:42.000Z
content/blog/behind Latina.md:
  digest: 2d811bf7f2371db22c3f8d79d73465ce298636ff3e6456e9a3260c45b8db7692
  filename: content/blog/behind Latina.md
  mtime: 1722408357000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-07-31T06:45:57.000Z
content/about/about me.md:
  digest: af0eb6cdaf106c801831f00d0bfb6c4ce3061c71da76594811c31ced9d4e7032
  filename: content/about/about me.md
  mtime: 1723225180000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-08-09T17:39:40.000Z
content/lingua/noun number.md:
  digest: 6a0cf8f84657bc470bfd94c28f4e68afccd6584e8d73c2ded7b125ced258487f
  filename: content/lingua/noun number.md
  mtime: 1725034446000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-08-30T16:14:06.000Z
content/lingua/noun case.md:
  digest: 2dd6dd35111b880f6592c9d60fea572a0aa748ec4ac63dbd9d03e90f4790af33
  filename: content/lingua/noun case.md
  mtime: 1725183585000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-09-01T09:39:45.000Z
content/lingua/verb conjugation.md:
  digest: a73fa59aa15087f2e0b3a0bf0aca4a472a0edbdab09b0197290856768e90305f
  filename: content/lingua/verb conjugation.md
  mtime: 1725182879000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-09-01T09:27:59.000Z
content/lingua/noun gender.md:
  digest: cbd8ffa0d17d20b782404ce20d1b2561d0e6aedc6029c1986b085e4010e38699
  filename: content/lingua/noun gender.md
  mtime: 1725105983000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-08-31T12:06:23.000Z
content/lingua/pronoun case.md:
  digest: a6cff8fa164410a106c3b21f393fefdaabd026f6c481b6acd287826b54d58573
  filename: content/lingua/pronoun case.md
  mtime: 1724318345000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-08-22T09:19:05.000Z
content/life management/kanban/game.md:
  digest: 0f5de97d8d0ba4230c390e0b81e47911ceb2e8577044f35cf81bf4858439874e
  filename: content/life management/kanban/game.md
  mtime: 1723040267000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-08-07T14:17:47.000Z
content/life management/kanban/template.md:
  digest: ee23a2659a54c35fb640cd5a17c4c05395911758b5ece9b0d52cd7321aa9fd4a
  filename: content/life management/kanban/template.md
  mtime: 1722173483000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-07-28T13:31:23.000Z
content/life management/time/game.md:
  digest: db78a5629514f9046f8f15851f91b25e3bb9b68933e301d7778a9ee2bd8ec629
  filename: content/life management/time/game.md
  mtime: 1723365861000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-08-11T08:44:21.000Z
content/life management/config/Obsidian Options.md:
  digest: 02a6b00457e680d9a871e96475f8d2f1aa854f923510d584cad8464d5fc7ada3
  filename: content/life management/config/Obsidian Options.md
  mtime: 1723117743000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-08-08T11:49:03.000Z
content/life management/config/NVIDIA Control Panel.md:
  digest: ec41aade491c822625a0e996f2eaf656287efe45afae6d58f16c24e8aa09d44d
  filename: content/life management/config/NVIDIA Control Panel.md
  mtime: 1722543926000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-08-01T20:25:26.000Z
content/life management/config/Windows Settings.md:
  digest: 8a24df4d7830992e49223bbc739c9b7773b1cb34265af50308062cd5cab77679
  filename: content/life management/config/Windows Settings.md
  mtime: 1722763436000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-08-04T09:23:56.000Z
content/opus/Wip/Untitled.md:
  digest: 0c689f64c1c42769556a840b40ca6b0438b31229043f86995f969cd32fbeef3e
  filename: content/opus/Wip/Untitled.md
  mtime: 1724707125660
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-08-26T21:18:45.660Z
content/opus/In Natura.md:
  digest: 0c6ad17da90ca5079a6b3dbccdbfc0c8afb3ae63c93a7ffe4f31c9a2313deab6
  filename: content/opus/In Natura.md
  mtime: 1725183475000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-09-01T09:37:55.000Z
content/opus/Universalo Declaratio de Humanas Justitias.md:
  digest: f15dc12117a12eee8c5636dc04cb8372dbf15eff37bc42b56fc01bac149bca1e
  filename: content/opus/Universalo Declaratio de Humanas Justitias.md
  mtime: 1725040814000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-08-30T18:00:14.000Z
content/opus/Documentation for Latina - Copy/6. Semantic.md:
  digest: 02ead0360dc4e50677ad1a65a34ed3d4c5b5a57b9f63cfde1c806eba4d25d95a
  filename: content/opus/Documentation for Latina - Copy/6. Semantic.md
  mtime: 1722416841000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-07-31T09:07:21.000Z
content/opus/Documentation for Latina - Copy/1. Phonology.md:
  digest: e21edac6bcdfe7413d3b33140108a6a0fe8b7d8987330d8c44f2ae63490bdd78
  filename: content/opus/Documentation for Latina - Copy/1. Phonology.md
  mtime: 1722426231000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-07-31T11:43:51.000Z
content/opus/Documentation for Latina - Copy/5. Pragmatic.md:
  digest: 1107a0ad3208b60fb44a2db0935159bcff90ebb45747ee43349e95e8e6701436
  filename: content/opus/Documentation for Latina - Copy/5. Pragmatic.md
  mtime: 1722416865000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-07-31T09:07:45.000Z
content/opus/Documentation for Latina - Copy/2. Morphology.md:
  digest: 192bb1322d6aa35c4f2f4c7b1c6f76bfcf63a7ae8ef32d3355e4775afaa60dca
  filename: content/opus/Documentation for Latina - Copy/2. Morphology.md
  mtime: 1723571038000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-08-13T17:43:58.000Z
content/opus/Documentation for Latina - Copy/7. Examples.md:
  digest: a652e70587fa2925e72a15b18705726b314faaf0f142516649b97016455ab3ba
  filename: content/opus/Documentation for Latina - Copy/7. Examples.md
  mtime: 1723981512000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-08-18T11:45:12.000Z
content/opus/Documentation for Latina - Copy/3. Syntax.md:
  digest: bcfc5ad172a20260608a05ef05dec095f783e434c16b60815c2df8e3b33513ce
  filename: content/opus/Documentation for Latina - Copy/3. Syntax.md
  mtime: 1723465786000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-08-12T12:29:46.000Z
content/opus/Documentation for Latina - Copy/4. Morphosyntax.md:
  digest: ca5a5ef077e6549510536f9f664c8e7f2db14e86198388bbe2ec389a89d23a06
  filename: content/opus/Documentation for Latina - Copy/4. Morphosyntax.md
  mtime: 1723983618000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-08-18T12:20:18.000Z
content/opus/fragmentus Heraclitut.md:
  digest: f4242e7b5fe5c7b666d6f323ce0e79e958a5b168d45cf55cf1c08196549514ed
  filename: content/opus/fragmentus Heraclitut.md
  mtime: 1724076093000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-08-19T14:01:33.000Z
FleetingNotesApp/START HERE.md:
  digest: ad897d828a83a12266e07a04709df89732cd5b201925348dc2221a82af741586
  filename: FleetingNotesApp/START HERE.md
  mtime: 1722073370000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-07-27T09:42:50.000Z
FleetingNotesApp/how to build connections in Fleeting Notes.md:
  digest: 3ccab701fc059faaf8ca24985f650d243bad1f26831186fe5e54c1eaa1c1800f
  filename: FleetingNotesApp/how to build connections in Fleeting Notes.md
  mtime: 1722073370000
  history:
    - zipName: 2024-9-1-79484.zip
      modified: 2024-07-27T09:42:50.000Z

```