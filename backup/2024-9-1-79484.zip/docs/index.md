# Hello, World!

Hi. This is my attempt to publish my Obsidian notes onto Github Pages.

## Is it working?

The `index.md` in the `/docs` folder is the homepage you see here.

The folders in `/docs` appear as the main sections on the navigation bar.
