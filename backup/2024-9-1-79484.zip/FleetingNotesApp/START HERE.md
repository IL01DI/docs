---
# Mandatory fields
id: "de2a360c-40e0-4e3e-8e38-be028d2a0b57"
# Optional fields
title: "START HERE"
tags: []
source: "https://fleetingnotes.app/faq/"
source_title: ""
source_description: ""
source_image_url: ""
created_date: "2024-07-27"
modified_date: "2024-07-27"
---
Fleeting Notes is a scratchpad for short-form notes use it to jot and connect ideas. See below for more info:

- [[how to build connections in Fleeting Notes]]
- [[how to sync notes with Obsidian]]
- [[what are backlinks]]

For more info, click to see the FAQ below.